from datetime import datetime
import requests
import pandas as pd
from datetime import datetime
import os
in_file_path = r'D:\sriram\agrud\prospectus_and_factsheet\schroder\schroder_data_links.csv'
fact_sheet_file_path = r'D:\\sriram\\agrud\\prospectus_and_factsheet\\schroder\\factsheet\\'
prospectus_file_path = r'D:\\sriram\\agrud\\prospectus_and_factsheet\\schroder\\prospectus\\'
date = datetime.today()

header = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cache-Control': 'max-age=0',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36',
    }

def download(file_path,link,master_id,i):
    if os.path.exists(file_path):
        print(str(i)+' '+str(master_id)+' file already exists')
        return 0
    res = requests.get(link,verify=False,stream=True,headers=header)
    with open(file_path, 'wb') as f:
        f.write(res.content)
    
def get_links():
    df = pd.read_csv(in_file_path)
    for i,row in df.iterrows():
        master_id = row[0]
        date2 = date.strftime('%Y%m%d')
        file_name = f'{master_id}_{date2}'
        # fact link pdf download
        try:
            link = row[2]
            file_path = fact_sheet_file_path+file_name+'.pdf'
            download(file_path,link,master_id,i)
            print(f"------------{master_id} fact-sheet downloaded----------------")
        except:
            pass

        # pros link pdf download
        try:
            link = row[3]
            file_path = prospectus_file_path+file_name+'.pdf'
            download(file_path,link,master_id,i)
            print(f"------------{master_id} prospectus downloaded----------------")
        except:
            pass

get_links()