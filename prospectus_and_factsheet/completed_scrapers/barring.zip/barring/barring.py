from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.ui import Select
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import csv
import time
from datetime import datetime
import pandas as pd
from bs4 import BeautifulSoup
data_file = r"D:\\sriram\\agrud\\prospectus_and_factsheet\\barring\\amc list (Factsheet & Prospectus) - Barring Final.csv"

def write_header():
    with open("barring_data_links.csv","a",newline="") as file:
        writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        writer.writerow(['isin name','master_id','factsheet_link','prospectus_link'])

def write_data(data):
    with open("barring_data_links.csv","a",newline="") as file:
        writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        writer.writerow(data)

def get_driver():
    s=Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    driver = webdriver.Chrome(service=s,options=options)
    # driver.minimize_window()
    return driver

def case1(driver,isin,master_id):
    prospectus = ""
    factsheet = ""
    driver.get("https://www.barings.com/lu/institutional")
    time.sleep(2)
    try:
        search_ele = WebDriverWait(driver,10).until(EC.element_to_be_clickable((By.ID,'search-bar')))
        search_ele.send_keys(isin)
    except:
        pass

    try:
        search_button = WebDriverWait(driver,5).until(EC.element_to_be_clickable((By.XPATH,'//*[@id="searchFormHeader"]/button')))
        search_button.click()
    except:
        pass

    try:
        view_button = WebDriverWait(driver,5).until(EC.element_to_be_clickable((By.XPATH,'//*[@class="button-viewpoint"]')))
        view_button.click()
    except:
        pass

    try:
        confirm_button = WebDriverWait(driver,5).until(EC.element_to_be_clickable((By.XPATH,'//*[@class="button-cta-confirm"]')))
        confirm_button.click()
    except:
        pass
    
    time.sleep(10)
    soup = BeautifulSoup(driver.page_source,'html5lib')
    links = soup.find('ul',{'class':'accordion'}).find_all('a')
    for link in links:
        if 'factsheet' in link.get('href').lower():
            factsheet = link.get('href')
        elif 'prospectus' in link.get('href').lower():
            prospectus = link.get('href')
            break        
    row = [isin,master_id,factsheet,prospectus]
    write_data(row)

def case2(driver,isin,master_id):
    prospectus = ""
    factsheet = ""
    driver.get("https://www.barings.com/ie/professional-investor")
    time.sleep(2)
    try:
        search_ele = WebDriverWait(driver,10).until(EC.element_to_be_clickable((By.ID,'search-bar')))
        search_ele.send_keys(isin)
    except:
        pass

    try:
        search_button = WebDriverWait(driver,5).until(EC.element_to_be_clickable((By.XPATH,'//*[@id="searchFormHeader"]/button')))
        search_button.click()
    except:
        pass

    try:
        view_button = WebDriverWait(driver,5).until(EC.element_to_be_clickable((By.XPATH,'//*[@class="button-viewpoint"]')))
        view_button.click()
    except:
        pass

    try:
        confirm_button = WebDriverWait(driver,5).until(EC.element_to_be_clickable((By.XPATH,'//*[@class="button-cta-confirm"]')))
        confirm_button.click()
    except:
        pass
    
    time.sleep(10)
    soup = BeautifulSoup(driver.page_source,'html5lib')
    links = soup.find('ul',{'class':'accordion'}).find_all('a')
    for link in links:
        if 'factsheet' in link.get('href').lower():
            factsheet = link.get('href')
        elif 'prospectus' in link.get('href').lower():
            prospectus = link.get('href')
            break        
    row = [isin,master_id,factsheet,prospectus]
    write_data(row)

def case3(driver,isin,master_id):
    prospectus = ""
    factsheet = ""
    driver.get("https://www.barings.com/ch/institutional/funds/")
    time.sleep(2)

    try:
        confirm_button = WebDriverWait(driver,5).until(EC.element_to_be_clickable((By.XPATH,'//*[@class="button-cta-confirm"]')))
        confirm_button.click()
    except:
        pass
    
    try:
        search_ele = WebDriverWait(driver,10).until(EC.element_to_be_clickable((By.ID,'search-bar')))
        search_ele.send_keys(isin)
    except:
        pass

    try:
        search_button = WebDriverWait(driver,5).until(EC.element_to_be_clickable((By.XPATH,'//*[@id="searchFormHeader"]/button')))
        search_button.click()
    except:
        pass

    try:
        view_button = WebDriverWait(driver,5).until(EC.element_to_be_clickable((By.XPATH,'//*[@class="button-viewpoint"]')))
        view_button.click()
    except:
        pass
    
    time.sleep(10)
    soup = BeautifulSoup(driver.page_source,'html5lib')
    links = soup.find('ul',{'class':'accordion'}).find_all('a')
    for link in links:
        if 'factsheet' in link.get('href').lower():
            factsheet = link.get('href')
        elif 'prospectus' in link.get('href').lower():
            prospectus = link.get('href')
            break        
    row = [isin,master_id,factsheet,prospectus]
    write_data(row)

def get_data():
    # write_header()
    isin_downloaded = []
    with open("barring_data_links.csv","r") as file:
        csvreader = csv.reader(file)
        header = next(csvreader)
        for row in csvreader:
            isin_downloaded.append(row[0])
    df = pd.read_csv(data_file,encoding="utf-8")
    df = df.drop_duplicates(subset=['Security ID'])
    search_list = [
        # 'https://www.barings.com/lu/institutional',
        # 'https://www.barings.com/ie/professional-investor',
        'https://www.barings.com/ch/institutional/funds/'
    ]
    driver = get_driver()
    for search in search_list:
        case = ''
        filter_df = df[df['domain'] == search]
        if '/lu/' in search:
            case = 1
        elif '/ie/' in search:
            case = 2
        elif '/ch/' in search:
            case = 3
        for i,row in filter_df.iterrows():
            isin = row[2]
            master_id = row[0]
            if isin not in isin_downloaded:
                if case == 1:
                    case1(driver,isin,master_id)
                if case == 2:
                    case2(driver,isin,master_id)
                if case == 3:
                    case3(driver,isin,master_id)

get_data()