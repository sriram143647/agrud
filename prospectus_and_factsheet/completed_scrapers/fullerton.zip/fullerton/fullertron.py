from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
import csv
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import time
from datetime import datetime
import pandas as pd
from bs4 import BeautifulSoup
from selenium.webdriver.chrome.service import Service
data_file = r"D:\\sriram\\agrud\\prospectus_and_factsheet\\fullerton\\amc list (Factsheet & Prospectus) - Fullerton.csv"

def write_header():
    with open("fullerton_data_links.csv","a",newline="") as file:
        writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        writer.writerow(['isin name','master_id','factsheet_link','prospectus_link'])

def write_output(data):
    with open("fullerton_data_links.csv","a",newline="") as file:
        writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        writer.writerow(data)

def get_driver():
    s=Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    driver = webdriver.Chrome(service=s,options=options)
    driver.minimize_window()
    return driver

def get_data():
    write_header()
    isin_downloaded = []
    with open("fullerton_data_links.csv","r") as file:
        csvreader = csv.reader(file)
        header = next(csvreader)
        for row in csvreader:
            isin_downloaded.append(row[0])
    df = pd.read_csv(data_file,encoding="utf-8")
    driver = get_driver()
    for i,row in df.iterrows():
        isin = row[2].strip()
        master_id = row[0]
        url = f'https://www.fullertonfund.com/literature/fullerton-fund/?_sft_registered=singapore&_sf_s={isin}'
        if isin not in isin_downloaded:
            driver.get(url)
            time.sleep(3)
            soup = BeautifulSoup(driver.page_source,'html5lib')
            links = soup.find('table',{'id':'fund-range'}).find_all('a')
            for link in links:
                if 'factsheets' in link.get('href') and 'EN' in link.text :
                    factsheet_link = link.get('href')
                elif 'prospectus' in link.get('href'):
                    prospectus_link = link.get('href')
            row = [isin,master_id,factsheet_link,prospectus_link]
            write_output(row)
    driver.quit()


get_data()