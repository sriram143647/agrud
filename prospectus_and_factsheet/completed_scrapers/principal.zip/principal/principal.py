from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.ui import Select
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.action_chains import ActionChains
from random import randint
import csv
import time
from datetime import datetime
import pandas as pd
from bs4 import BeautifulSoup
data_file = r"D:\\sriram\\agrud\\prospectus_and_factsheet\\principal\\amc list (Factsheet & Prospectus) - Principal.csv"

def write_header():
    with open("principal_data_links.csv","a",newline="") as file:
        writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        writer.writerow(['master_id','isin name','factsheet_link','prospectus_link'])

def write_output(data):
    with open("principal_data_links.csv","a",newline="") as file:
        writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        writer.writerow(data)

def get_driver():
    s=Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    driver = webdriver.Chrome(service=s,options=options)
    # driver.minimize_window()
    return driver

def case1(driver,isin,master_id):
    factsheet_link = ''
    prospectus_link = ''
    link = 'https://www.fundinfo.com/en'
    driver.get(link)
    try:
        accept_btn = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.XPATH,'//*[@id="qc-cmp2-ui"]/div[2]/div/button[2]')))
        accept_btn.click()
    except:
        pass

    try:
        country_select = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.XPATH,'//*[@class="country-selector"]')))
        country_select.click()
    except Exception as e:
        pass

    try:
        select_country = WebDriverWait(driver,3).until(EC.element_to_be_clickable((By.XPATH,'//*[@data-cname="Ireland"]')))
        driver.execute_script("arguments[0].click();", select_country)
    except Exception as e:
        pass

    try:
        tick_mark = WebDriverWait(driver,3).until(EC.element_to_be_clickable((By.XPATH,'//*[@for="fund-market-checkbox-mandatory"]/span')))
        driver.execute_script("arguments[0].click();", tick_mark)
    except Exception as e:
        pass
    
    try:
        confirm = WebDriverWait(driver,3).until(EC.element_to_be_clickable((By.XPATH,'//*[@class="btn fundmarket-btn confirm"]')))
        confirm.click()
    except Exception as e:
        pass

    try:
        search_ele = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.XPATH,'//*[@placeholder="Place your search request here ( fund name / ISIN / WKN / Valor No )"]')))
        search_ele.send_keys(str(isin))
    except:
        pass

    try:
        btn = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.XPATH,'//*[@class="searchButton"]')))
        btn.click()
    except:
        pass

    time.sleep(10)
    try:
        url_ele_1 = driver.find_element(By.XPATH,'//*[@data-name="MR"]')
        hover_act = ActionChains(driver).move_to_element(url_ele_1)
        hover_act.perform()
    except:
        pass

    try:
        drop_down_btn = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.XPATH,'//*[@class="collapse collapse-open"]')))
        drop_down_btn.click()
    except:
        pass

    try:
        url_ele_2 = driver.find_element(By.XPATH,'//*[@data-name="PR"]')
        hover_act = ActionChains(driver).move_to_element(url_ele_2)
        hover_act.perform()
    except:
        pass

    soup = BeautifulSoup(driver.page_source,'html5lib')
    factsheet_link = soup.find('div',{'data-name':'MR'}).find('a').get('href')
    prospectus_link = soup.find('div',{'data-name':'PR'}).find('a').get('href')
    row = [master_id,isin,factsheet_link,prospectus_link]
    write_output(row)
    
def get_data():
    write_header()
    isin_downloaded = []
    with open("principal_data_links.csv","r") as file:
        csvreader = csv.reader(file)
        header = next(csvreader)
        for row in csvreader:
            isin_downloaded.append(row[1])
    df = pd.read_csv(data_file,encoding="utf-8")
    df = df.drop_duplicates(subset=['Security ID'])
    search_list = [
        'https://www.fundinfo.com/en/IE-prof/LandingPage?query',
        'https://www.fundinfo.com/en/GB-prof/LandingPage?query'
    ]
    driver = get_driver()
    for search in search_list:
        case = ''
        filter_df = df[df['domain'] == search]
        if '/IE-prof/' in search:
            case = 1
        elif '/GB-prof/' in search:
            case = 2
        for i,row in filter_df.iterrows():
            isin = row[2]
            master_id = row[0]
            if isin not in isin_downloaded:
                if case == 1:
                    case1(driver,isin,master_id)
                if case == 2:
                    case1(driver,isin,master_id)

get_data()