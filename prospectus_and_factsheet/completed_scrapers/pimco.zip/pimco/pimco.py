from lib2to3.pgen2 import driver
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains    
import time,csv
from bs4 import BeautifulSoup
import pandas as pd
data_file = r"D:\\sriram\\agrud\\prospectus_and_factsheet\\pimco\\amc list (Factsheet & Prospectus) - Pimco Final.csv"

def get_driver():
    s=Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    driver = webdriver.Chrome(service=s,options=options)
    # driver.minimize_window()
    return driver

def write_header():
    with open("pimco_data_links.csv", mode='a',encoding="utf-8",newline="") as file:
        writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        writer.writerow(['isin name','master_id','prospectus_link','factsheet_link'])

def write_data(data):
    with open('pimco_data_links.csv', mode='a',encoding="utf-8",newline="") as output_file:
        writer = csv.writer(output_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        writer.writerow(data)
        output_file.close()

def case1(driver,isin,master_id):
    prospectus_link = ""
    factsheet_link = ""
    driver.get("https://www.pimco.com.sg/en-sg/")
    time.sleep(2)
    try:
        click_ele = WebDriverWait(driver,3).until(EC.element_to_be_clickable((By.XPATH,'//*[@id="SplashPage0"]/section/div/div[7]/ul/li[3]/label')))
        click_ele.click()
    except:
        pass
    time.sleep(2)
    try:
        click_button = WebDriverWait(driver,3).until(EC.element_to_be_clickable((By.ID,'yes')))
        click_button.click()
    except:
        pass
    driver.get(f"https://www.pimco.com.sg/en-sg/search#q={isin}")
    time.sleep(2)
    for ele in driver.find_elements(By.CLASS_NAME,'CoveoResultLink'):
        if isin in ele.text:
            ele.click()
            try:
                if factsheet_link == '':
                    factsheet_link = WebDriverWait(driver,10).until(EC.visibility_of_element_located((By.XPATH,"//a[@aria-label='Fund Fact Sheet pdf']"))).get_attribute('href')
            except :
                pass
            
            try:
                if prospectus_link == '':
                    prospectus_link = WebDriverWait(driver,10).until(EC.visibility_of_element_located((By.XPATH,"//a[@aria-label='Prospectus pdf']"))).get_attribute('href')
            except:
                pass
            row = [master_id,isin,prospectus_link,factsheet_link]
            write_data(row)

def case2(driver,isin,master_id):
    prospectus_link = ""
    factsheet_link = ""
    driver.get("https://www.pimco.lu/en-lu/?showSplash=1")
    time.sleep(2)
    try:
        click_button = WebDriverWait(driver,3).until(EC.element_to_be_clickable((By.ID,'onetrust-accept-btn-handler')))
        click_button.click()
    except:
        pass
    time.sleep(5)
    try:
        click_ele = WebDriverWait(driver,3).until(EC.element_to_be_clickable((By.ID,'Financial Intermediary')))
        click_ele.click()
    except Exception as e:
        pass
    time.sleep(5)
    try:
        click_button = WebDriverWait(driver,3).until(EC.element_to_be_clickable((By.ID,'yes')))
        click_button.click()
    except:
        pass
    link = f'https://www.pimco.lu/en-lu/search#q={isin}'
    driver.get(link)
    time.sleep(10)
    for ele in driver.find_elements(By.CLASS_NAME,'CoveoResultLink'):
        if isin in ele.text:
            ele.click()
            soup = BeautifulSoup(driver.page_source,'html5lib')
            try:
                click_button = WebDriverWait(driver,3).until(EC.element_to_be_clickable((By.ID,'yes')))
                click_button.click()
            except:
                pass
            try:
                if factsheet_link == '':
                    factsheet_link = WebDriverWait(driver,10).until(EC.visibility_of_element_located((By.XPATH,'//*[@id="FactSheet"]'))).get_attribute('href')
            except:
                pass
            
            try:
                if prospectus_link == '':
                    prospectus_link = WebDriverWait(driver,10).until(EC.visibility_of_element_located((By.XPATH,'//*[@id="Prospectus"]'))).get_attribute('href')
            except:
                pass
            row = [master_id,isin,prospectus_link,factsheet_link]
            write_data(row)

def case3(driver,isin,master_id):
    pass

def get_data():
    # write_header()
    isin_downloaded = []
    with open("pimco_data_links.csv","r") as file:
        csvreader = csv.reader(file)
        header = next(csvreader)
        for row in csvreader:
            isin_downloaded.append(row[1])
    df = pd.read_csv(data_file,encoding="utf-8")
    df = df.drop_duplicates(subset=['Security ID'])
    search_list = [
        'https://www.pimco.com.sg/en-sg/',
        # 'https://www.pimco.lu/en-lu/',
        # 'https://europe.pimco.com/en-eu/investments'
    ]
    driver = get_driver()
    for search in search_list:
        case = ''
        filter_df = df[df['Domin'] == search]
        if '.sg' in search:
            case = 1
        elif 'en-lu/' in search:
            case = 1
        elif 'en-eu/' in search:
            case = 1
        for i,row in filter_df.iterrows():
            isin = row[2]
            master_id = row[0]
            if isin not in isin_downloaded:
                if case == 1:
                    case1(driver,isin,master_id)
                if case == 2:
                    case2(driver,isin,master_id)


get_data()