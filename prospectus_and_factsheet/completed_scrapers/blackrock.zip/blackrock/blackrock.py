from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
import csv
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import time
from datetime import datetime
import pandas as pd
from bs4 import BeautifulSoup
from selenium.webdriver.chrome.service import Service
data_file = r"D:\sriram\agrud\prospectus_and_factsheet\blackrock_com\amc list (Factsheet & Prospectus) - BGF.csv"

def write_header():
    with open("blackrock_data_links.csv","a",newline="") as file:
        writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        writer.writerow(['isin name','master_id','factsheet_link','prospectus_link'])

def write_output(data):
    with open("blackrock_data_links.csv","a",newline="") as file:
        writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        writer.writerow(data)

def get_driver():
    s=Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    driver = webdriver.Chrome(service=s,options=options)
    driver.minimize_window()
    return driver

def case1(driver,isin,master_id):
    driver.get("https://www.blackrock.com/hk/en")
    time.sleep(3)
    try:
        agree_btn = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.ID,'onetrust-accept-btn-handler')))
        agree_btn.click()
    except:
        pass
    click_ele = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.CLASS_NAME,'search-box')))
    click_ele.click()
    search_ele = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.ID, 'searchText')))
    search_ele.send_keys(str(isin))
    search_click = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.CLASS_NAME,'submitSearch')))
    search_click.click()
    try:
        accept_btn = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.ID,'terms-and-conditions-masthead-accept')))
        accept_btn.click()
    except:
        pass
    soup = BeautifulSoup(driver.page_source,'html5lib')
    links = soup.find('ul',{'id':'fundHeaderDocLinks'}).find_all('a')
    for link in links:
        if 'Factsheet' in link.text :
            factsheet_link = 'https://www.blackrock.com'+link.get('href')
        elif 'Prospectus' in link.text:
            prospectus_link = 'https://www.blackrock.com'+link.get('href')
    row = [isin,master_id,factsheet_link,prospectus_link]
    write_output(row)

def case2(driver,isin,master_id):
    driver.get("https://www.blackrock.com/sg/en")
    time.sleep(3)
    try:
        agree_btn = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.ID,'onetrust-accept-btn-handler')))
        agree_btn.click()
    except:
        pass
    click_ele = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.CLASS_NAME,'search-box')))
    click_ele.click()
    search_ele = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.ID, 'searchText')))
    search_ele.send_keys(str(isin))
    search_click = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.CLASS_NAME,'submitSearch')))
    search_click.click()
    try:
        accept_btn = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.ID,'terms-and-conditions-masthead-accept')))
        accept_btn.click()
    except:
        pass
    soup = BeautifulSoup(driver.page_source,'html5lib')
    links = soup.find('ul',{'id':'fundHeaderDocLinks'}).find_all('a')
    for link in links:
        if ' Fact Sheet' in link.text :
            factsheet_link = 'https://www.blackrock.com'+link.get('href')
        elif 'Prospectus' in link.text:
            prospectus_link = 'https://www.blackrock.com'+link.get('href')
    row = [isin,master_id,factsheet_link,prospectus_link]
    write_output(row)

def case3(driver,isin,master_id):
    driver.get("https://www.blackrock.com/ch/professionals/en")
    time.sleep(3)
    try:
        agree_btn = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.ID,'onetrust-accept-btn-handler')))
        agree_btn.click()
    except:
        pass
    click_ele = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.CLASS_NAME,'search-button')))
    click_ele.click()
    search_ele = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.ID, 'searchText')))
    search_ele.send_keys(str(isin))
    search_click = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.CLASS_NAME,'submitSearch')))
    search_click.click()
    try:
        accept_btn = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.ID,'terms-and-conditions-masthead-accept')))
        accept_btn.click()
    except:
        pass
    soup = BeautifulSoup(driver.page_source,'html5lib')
    links = soup.find('ul',{'id':'fundHeaderDocLinks'}).find_all('a')
    for link in links:
        if ' Factsheet' in link.text :
            factsheet_link = 'https://www.blackrock.com'+link.get('href')
        elif 'Prospectus' in link.text:
            prospectus_link = 'https://www.blackrock.com'+link.get('href')
    row = [isin,master_id,factsheet_link,prospectus_link]
    write_output(row)

def get_data():
    write_header()
    isin_downloaded = []
    with open("blackrock_data_links.csv","r") as file:
        csvreader = csv.reader(file)
        header = next(csvreader)
        for row in csvreader:
            isin_downloaded.append(row[0])
    df = pd.read_csv(data_file,encoding="utf-8")
    df = df.drop_duplicates(subset=['Security ID'])
    links = [
        # 'https://www.blackrock.com/hk/en',
        # 'https://www.blackrock.com/sg/en',
        'https://www.blackrock.com/ch/professionals/en',
    ]
    for link in links:
        case = ''
        if '/hk/en' in link:
            case = 1
        if '/sg/en' in link:
            case = 2
        if '/ch/professionals/en' in link:
            case = 3
        blackrock_df = df[df['domain'] == link]
        driver = get_driver()
        for i,row in blackrock_df.iterrows():
            isin = row[2]
            master_id = row[0]
            if isin not in isin_downloaded:
                if case == 1:
                    case1(driver,isin,master_id)
                if case == 2:
                    case2(driver,isin,master_id)
                if case == 3:
                    case3(driver,isin,master_id)
get_data()