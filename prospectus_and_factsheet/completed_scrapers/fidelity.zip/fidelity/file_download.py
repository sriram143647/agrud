from datetime import datetime
import requests
import pandas as pd
import numpy as np
from datetime import datetime
import os
in_file_path = r'D:\sriram\agrud\prospectus_and_factsheet\fidelity_com\fidelity_data_links.csv'
fact_sheet_file_path = r'D:\\sriram\\agrud\\prospectus_and_factsheet\\franklintempleton_com\\factsheet\\'
prospectus_file_path = r'D:\\sriram\\agrud\\prospectus_and_factsheet\\franklintempleton_com\\prospectus\\'
date = datetime.today()

header = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
    }

def download(file_path,link,master_id,i):
    if os.path.exists(file_path):
        print(str(i)+' '+str(master_id)+' file already exists')
        return 0
    res = requests.get(link,verify=False,stream=True,headers=header)
    # wget.download(link,bar=wget.bar_adaptive,out = file_path)
    with open(file_path, 'wb') as f:
        f.write(res.content)
    
def get_links():
    df = pd.read_csv(in_file_path)
    for i,row in df.iterrows():
        master_id = row[1]
        date2 = date.strftime('%Y%m%d')
        file_name = f'{master_id}_{date2}'
        # fact link pdf download
        try:
            link = row[2]
            file_path = fact_sheet_file_path+file_name+'.pdf'
        except:
            pass
        # pros link pdf download
        try:
            link = row[3]
            file_path = prospectus_file_path+file_name+'.pdf'
        except:
            pass
        
        download(file_path,link,master_id,i)
        print(f"------------{master_id} File's downloaded----------------")

get_links()