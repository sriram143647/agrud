from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
import csv
from bs4 import BeautifulSoup
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.service import Service
import pandas as pd
data_file = r"D:\\sriram\\agrud\\prospectus_and_factsheet\\amc list (Factsheet and Prospectus) - Global MF.csv"

def write_header():
    with open("fidelity_data_links.csv","a",newline="") as file:
        writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        writer.writerow(['isin name','master_id','factsheet_link','prospectus_link'])

def write_output(data):
    with open("fidelity_data_links.csv","a",newline="") as file:
        writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
        writer.writerow(data)
        
def get_driver():
    s=Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    driver = webdriver.Chrome(service=s,options=options)
    driver.minimize_window()
    return driver

def get_data():
    # write_header()
    isin_downloaded = []
    with open("fidelity_data_links.csv","r") as file:
        csvreader = csv.reader(file)
        header = next(csvreader)
        for row in csvreader:
            isin_downloaded.append(row[0])
    df = pd.read_csv(data_file,encoding="utf-8")
    fidelity_df = df[df['domain']=="https://www.fidelity.com.sg/"]
    fidelity_df = fidelity_df.drop_duplicates(subset=['master_id'])
    driver = get_driver()
    for i,row in fidelity_df.iterrows():
        isin = row[7]
        master_id = row[0]
        if isin not in isin_downloaded:
            driver.get("https://www.fidelity.com.sg/")
            click_ele = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.ID,'searchInput')))
            click_ele.click()
            search_ele = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.ID, 'searchInput')))
            search_ele.send_keys(str(isin))
            link_ele = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.XPATH,'//*[@class="item link"]/div')))
            link_ele.click()
            try:
                close_ele = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.XPATH,'//*[@id="liveForm"]/div/div[1]/div/button')))
                close_ele.click()                
            except:
                pass
            doc_tab = WebDriverWait(driver,3).until(EC.visibility_of_element_located((By.ID, 'tab-documents-label')))
            doc_tab.click()
            soup = BeautifulSoup(driver.page_source,'html5lib')
            cols = soup.find('table',{'class':'table-regular'}).find('tbody').find_all('tr')
            for col in cols:
                if 'Factsheet' in col.text:
                    if col.find('a').text == 'English':
                        factsheet_link = col.find('a').get('href')
                elif 'Prospectus' in col.text:
                    prospectus_link = col.find('a').get('href')
            row = [isin,master_id,factsheet_link,prospectus_link]
            write_output(row)

get_data()